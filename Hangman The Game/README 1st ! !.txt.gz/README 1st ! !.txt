1.If you want to run the game,copy the "Hangman The Game" folder and put it in the ROOT of C:\ or D:\ drive or in your pendrive.
2.This game is also portable and can be stored in the pendrive. Put this "Hangman The Game" folder in root directory of your pendrive and play.
3.Run the game using the "Hangman The Game.jar"provided in this folder.
4.By default the admin username = "admin"
                       password = "admin"
5.Enjoy.